-- Databricks notebook source
CREATE DATABASE IF NOT EXISTS f1_presentation 
LOCATION "/mnt/formularacedlaccount/presentation"

-- COMMAND ----------

DESC DATABASE f1_presentation;