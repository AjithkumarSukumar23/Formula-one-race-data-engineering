# Databricks notebook source
raw_folder_path = "/mnt/formularacedlaccount/raw"
processed_folder_path = "/mnt/formularacedlaccount/processed"
presentation_folder_path = "/mnt/formularacedlaccount/presentation"